package com.ista.ejercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsProyectoUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
