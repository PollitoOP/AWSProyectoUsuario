package com.ista.ejercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsProyectoUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsProyectoUsuarioApplication.class, args);
		System.out.println("AWSProyectoUsuario en Ejecución...");
	}

}
